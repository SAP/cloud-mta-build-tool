company.ui.define([
	"company/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("aa.ui5app.controller.View1", {

	});
});